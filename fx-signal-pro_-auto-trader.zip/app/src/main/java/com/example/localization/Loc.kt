package com.example.localization

enum class Language {
    RU, EN
}

object Loc {
    var currentLanguage = Language.RU

    fun get(key: String): String {
        val dict = if (currentLanguage == Language.RU) ruDict else enDict
        return dict[key] ?: key
    }

    private val ruDict = mapOf(
        "app_title" to "FxSignals AI",
        "tab_trade" to "Торговля",
        "tab_history" to "История",
        "tab_stats" to "Статистика",
        "tab_settings" to "Настройки",
        "tab_logs" to "Логи",

        "mode_manual" to "Ручной режим",
        "mode_auto" to "Авто-режим",
        "autotrade_active" to "АВТОТОРГОВЛЯ АКТИВНА",
        "autotrade_inactive" to "АВТОТОРГОВЛЯ ОТКЛЮЧЕНА",
        "autotrade_toggle" to "Переключатель автоторговли",
        "autotrade_desc" to "Система будет автоматически входить в сделки при вероятности выше порога.",

        "direction_call" to "ВВЕРХ (CALL)",
        "direction_put" to "ВНИЗ (PUT)",
        "direction_nosignal" to "НЕТ СИГНАЛА (NO SIGNAL)",

        "lbl_pair" to "Валютная пара",
        "lbl_candle" to "Таймфрейм свечей",
        "lbl_duration" to "Время сделки",
        "lbl_probability" to "Уверенность сигнала",
        "lbl_reasons" to "Причины сигнала",
        "lbl_recommendations" to "Рекомендация",
        "lbl_state" to "Состояние рынка",
        "lbl_active_trades" to "Активные сделки",
        "lbl_balance" to "Ваш демо-баланс",

        "state_normal" to "Умеренный тренд",
        "state_flat" to "Флэт (Боковик)",
        "state_volatile" to "Высокая волатильность",
        "state_weak" to "Слабый (сомнительный) рынок",
        "state_news" to "Ожидание новостей (повышенный риск)",

        "rec_wait" to "Рекомендуется подождать четких условий.",
        "rec_call" to "Открытие сделки на повышение (CALL) обосновано.",
        "rec_put" to "Открытие сделки на понижение (PUT) обосновано.",

        "filter_time" to "Фильтр сессий",
        "filter_volatility" to "Фильтр волатильности",
        "filter_news" to "Фильтр новостей",

        "news_impact_high" to "ВАЖНОЕ СОБЫТИЕ: Повышенный риск на {currency}",
        "news_impact_none" to "Новостной фон спокойный",

        "btn_analyze" to "Анализировать рынок",
        "btn_clear_history" to "Очистить историю",
        "btn_export" to "Экспорт CSV",
        "btn_save" to "Сохранить",

        "stats_winrate" to "Процент побед (Win Rate)",
        "stats_total" to "Всего сделок",
        "stats_wins" to "Выигрышные сделки",
        "stats_losses" to "Проигрышные сделки",
        "stats_nosignals" to "Пропущено (No Signal)",
        "stats_best_pair" to "Лучшая пара",
        "stats_best_hour" to "Лучший час торговой сессии",
        "stats_best_tf" to "Лучший таймфрейм",
        "stats_avg_prob" to "Средняя уверенность сделки",

        "cfg_lang" to "Язык приложения",
        "cfg_threshold" to "Порог уверенности для входа",
        "cfg_sound" to "Звуковые сигналы",
        "cfg_push" to "Push-уведомления",
        "cfg_bet" to "Размер ставки ($)",
        "cfg_limit_day" to "Лимит сделок в день",
        "cfg_limit_loss" to "Лимит убытков ($)",
        "cfg_anti_streak" to "Защита от серий потерь",
        "cfg_only_strong" to "Режим \"Только сильные сигналы\" (85%+)",
        "cfg_fake_notifications" to "Имитировать системную шторку",

        "log_start" to "Система запущена.",
        "log_manual_check" to "Запущен ручной анализ для {pair}.",
        "log_auto_check" to "Автоматический сканер проверил {pair}. Результат: {signal}",
        "log_trade_open" to "Открыта сделка: {pair} на {dir}, уверенность {prob}%, ставка {bet}$.",
        "log_trade_success" to "[WIN] Сделка по {pair} закрылась в плюс. Выигрыш: {profit}$.",
        "log_trade_fail" to "[LOSS] Сделка по {pair} закрылась в минус. Убыток: {bet}$.",
        "log_limit_hit" to "[РМ] Достигнут дневной лимит! Сделка заблокирована.",
        "log_news_block" to "[ФИЛЬТР] Вход отменен: высокая волатильность из-за новостей по {currency}.",
        "log_time_block" to "[ФИЛЬТР] Вход отменен: неактивная торговая сессия.",

        "search_hint" to "Поиск по паре...",
        "sort_by" to "Сортировка",
        "sort_date" to "Дата",
        "sort_pair" to "Валютная пара",
        "sort_result" to "Результат",
        "filter_result" to "Фильтр по результату",
        "all" to "Все",
        "wins" to "Победы",
        "losses" to "Убытки",

        "reason_rsi_ob" to "Индикатор RSI указывает на сильную перекупленность (>70).",
        "reason_rsi_os" to "Индикатор RSI указывает на сильную перепроданность (<30).",
        "reason_ema_golden" to "EMA пересекла SMA снизу вверх, сигнализируя бычий тренд.",
        "reason_ema_death" to "EMA пересекла SMA сверху вниз, сигнализируя медвежий тренд.",
        "reason_macd_up" to "Гистограмма MACD растет в положительной зоне, сильный тренд.",
        "reason_macd_down" to "Гистограмма MACD снижается в отрицательной зоне, падение тренда.",
        "reason_bb_upper" to "Цена тестирует верхнюю границу Bollinger Bands, возможен откат.",
        "reason_bb_lower" to "Цена тестирует нижнюю границу Bollinger Bands, возможен отскок.",
        "reason_conflict" to "Индикаторы противоречат друг другу: SMA растет, а Stochastic падает.",
        "reason_weak_market" to "Рыночная активность слишком слабая. Объем торгов незначительный.",
        "reason_volatile_news" to "Рынок хаотичен на фоне скорых новостей. Торговать небезопасно.",
        "reason_stoch_up" to "Stochastic Oscillator вышел из зоны перепроданности вверх.",
        "reason_stoch_down" to "Stochastic Oscillator вышел из зоны перекупленности вниз.",
        
        "empty_history" to "История сделок пуста. Сделайте первую операцию!",
        "active_trades_header" to "Текущие сделки в рынке",
        "ai_explanation_request" to "Запросить AI-объяснение от Gemini",
        "ai_expl_loading" to "AI анализирует текущий паттерн...",
        "ai_expl_no_api" to "Gemini API не настроен. Добавьте GEMINI_API_KEY в Secrets.",
        "ai_expl_general" to "Рыночный отчет AI"
    )

    private val enDict = mapOf(
        "app_title" to "FxSignals AI",
        "tab_trade" to "Trading",
        "tab_history" to "History",
        "tab_stats" to "Statistics",
        "tab_settings" to "Settings",
        "tab_logs" to "Logs",

        "mode_manual" to "Manual Mode",
        "mode_auto" to "Auto Mode",
        "autotrade_active" to "AUTOTRADE ACTIVE",
        "autotrade_inactive" to "AUTOTRADE INACTIVE",
        "autotrade_toggle" to "Auto-Trading Switch",
        "autotrade_desc" to "The system will automatically enter trades when signals exceed your probability rate threshold.",

        "direction_call" to "UP (CALL)",
        "direction_put" to "DOWN (PUT)",
        "direction_nosignal" to "NO SIGNAL",

        "lbl_pair" to "Currency Pair",
        "lbl_candle" to "Candle Timeframe",
        "lbl_duration" to "Trade Duration",
        "lbl_probability" to "Signal Confidence",
        "lbl_reasons" to "Analysis Reasons",
        "lbl_recommendations" to "Recommendation",
        "lbl_state" to "Market State",
        "lbl_active_trades" to "Active Trades",
        "lbl_balance" to "Demo Balance",

        "state_normal" to "Moderate Trend",
        "state_flat" to "Flat (Sideways Range)",
        "state_volatile" to "Extremely Volatile",
        "state_weak" to "Weak / Silent Market",
        "state_news" to "Impending News (High Risk)",

        "rec_wait" to "It is recommended to stand aside and wait for clearer conditions.",
        "rec_call" to "Opening an upward position (CALL) is justified.",
        "rec_put" to "Opening a downward position (PUT) is justified.",

        "filter_time" to "Trading Session Filter",
        "filter_volatility" to "Volatility Filter",
        "filter_news" to "News Filter",

        "news_impact_high" to "HIGH IMPACT EVENT: Increased risks for {currency}",
        "news_impact_none" to "No high-impact economic news nearby",

        "btn_analyze" to "Analyze Market",
        "btn_clear_history" to "Clear History",
        "btn_export" to "Export CSV",
        "btn_save" to "Save Settings",

        "stats_winrate" to "Win Rate percentage",
        "stats_total" to "Total Trades",
        "stats_wins" to "Winning Trades",
        "stats_losses" to "Losing Trades",
        "stats_nosignals" to "No Signals generated",
        "stats_best_pair" to "Best Performing Pair",
        "stats_best_hour" to "Best Trading Hour",
        "stats_best_tf" to "Best Timeframe",
        "stats_avg_prob" to "Average Trade Confidence",

        "cfg_lang" to "App Language",
        "cfg_threshold" to "Signal Confidence Threshold",
        "cfg_sound" to "Sound Effects",
        "cfg_push" to "Push Notifications",
        "cfg_bet" to "Trade Capital Size ($)",
        "cfg_limit_day" to "Daily Trade Limit",
        "cfg_limit_loss" to "Max Daily Loss ($)",
        "cfg_anti_streak" to "Loss Streak Protection",
        "cfg_only_strong" to "Only Extreme Signals mode (85%+)",
        "cfg_fake_notifications" to "Simulate system notifications",

        "log_start" to "System started.",
        "log_manual_check" to "Started manual analysis for {pair}.",
        "log_auto_check" to "Auto scanner checked {pair}. Result: {signal}",
        "log_trade_open" to "Opened position: {pair} on {dir}, confidence {prob}%, bet {bet}$.",
        "log_trade_success" to "[WIN] Trade on {pair} finished in profit. Win: {profit}$.",
        "log_trade_fail" to "[LOSS] Trade on {pair} closed in loss. Loss: {bet}$.",
        "log_limit_hit" to "[RM] Daily limit hit! Trading activity suspended.",
        "log_news_block" to "[FILTER] Entry blocked: high volatility due to news on {currency}.",
        "log_time_block" to "[FILTER] Entry blocked: inactive trading session.",

        "search_hint" to "Search pair...",
        "sort_by" to "Sort by",
        "sort_date" to "Date",
        "sort_pair" to "Currency Pair",
        "sort_result" to "Result",
        "filter_result" to "Filter by result",
        "all" to "All",
        "wins" to "Wins",
        "losses" to "Losses",

        "reason_rsi_ob" to "RSI indicates strong overbought conditions (>70).",
        "reason_rsi_os" to "RSI indicates strong oversold conditions (<30).",
        "reason_ema_golden" to "EMA crossed above SMA (Golden Cross), indicating a bullish trend.",
        "reason_ema_death" to "EMA crossed below SMA (Death Cross), indicating a bearish trend.",
        "reason_macd_up" to "MACD histogram is expanding upwards in positive territory, strong buyer force.",
        "reason_macd_down" to "MACD histogram is sinking in negative territory, sellers are dominating.",
        "reason_bb_upper" to "Price is testing the upper Bollinger Band. Pullback is likely.",
        "reason_bb_lower" to "Price is testing the lower Bollinger Band. Bounce is likely.",
        "reason_conflict" to "Indicator divergence: SMA is climbing but Stochastic points down.",
        "reason_weak_market" to "Market activity is too low. Negligible volume trading.",
        "reason_volatile_news" to "High noise on upcoming news events. Entering is high-risk.",
        "reason_stoch_up" to "Stochastic Oscillator bounced back up from oversold territory.",
        "reason_stoch_down" to "Stochastic Oscillator turned back down from overbought territory.",

        "empty_history" to "Trade history is empty. Try your first trade!",
        "active_trades_header" to "Current Active Market Trades",
        "ai_explanation_request" to "Query AI Analysis from Gemini",
        "ai_expl_loading" to "AI analyzing current asset conditions...",
        "ai_expl_no_api" to "Gemini API key is missing. Configure 'GEMINI_API_KEY' in your Secrets.",
        "ai_expl_general" to "AI Market Intelligence"
    )
}
