package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.database.Trade
import com.example.database.TradeRepository
import com.example.localization.Language
import com.example.localization.Loc
import com.example.trading.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import kotlin.random.Random

data class ActiveTrade(
    val id: String,
    val pair: String,
    val entryPrice: Double,
    val direction: String, // "CALL", "PUT"
    val stake: Double,
    val durationText: String,
    val totalSeconds: Int,
    var secondsRemaining: Int,
    val initialProbability: Int,
    val isAuto: Boolean,
    val startTimestamp: Long = System.currentTimeMillis()
)

data class NotificationMessage(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val title: String,
    val message: String,
    val isWin: Boolean? = null
)

class TradingViewModel(private val repository: TradeRepository) : ViewModel() {

    // --- Configurations / Settings ---
    val appLanguage = MutableStateFlow(Language.RU)
    val probabilityThreshold = MutableStateFlow(75) // 75% default
    val soundEnabled = MutableStateFlow(true)
    val notificationsEnabled = MutableStateFlow(true)
    val isAutoTrading = MutableStateFlow(false)
    val betSize = MutableStateFlow(100.0)
    
    // Filters
    val sessionFilterEnabled = MutableStateFlow(true)
    val volatilityFilterEnabled = MutableStateFlow(true)
    val newsFilterEnabled = MutableStateFlow(true)
    
    // Limits
    val dailyLimitCount = MutableStateFlow(25)
    val dailyLossLimit = MutableStateFlow(1500.0)
    val antiLossStreakProtection = MutableStateFlow(true)
    val onlyStrongSignalsMode = MutableStateFlow(false)

    // Demo Balance
    val balance = MutableStateFlow(10000.0)

    // --- Selected Trading State ---
    val selectedPair = MutableStateFlow("EUR/USD")
    val selectedCandleTimeframe = MutableStateFlow("1m") // 1m, 2m, 3m, 5m
    val selectedTradeDuration = MutableStateFlow("1m") // 1m, 2m, 3m, 4m, 5m, 10m, 15m, 30m, 1h

    // Generated simulation variables
    private var marketSeed = Random.nextLong()
    private val candleMutex = Any()
    private val _candles = MutableStateFlow<List<Candle>>(emptyList())
    val candles: StateFlow<List<Candle>> = _candles.asStateFlow()

    private val _signalResult = MutableStateFlow<SignalResult?>(null)
    val signalResult: StateFlow<SignalResult?> = _signalResult.asStateFlow()

    // Active Options positions ticking state
    private val _activeTrades = MutableStateFlow<List<ActiveTrade>>(emptyList())
    val activeTrades: StateFlow<List<ActiveTrade>> = _activeTrades.asStateFlow()

    // Notifications display stack
    private val _notifications = MutableStateFlow<List<NotificationMessage>>(emptyList())
    val notifications: StateFlow<List<NotificationMessage>> = _notifications.asStateFlow()

    // Database state mappings
    val tradeHistory: StateFlow<List<Trade>> = repository.allTrades
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val logs: StateFlow<List<com.example.database.AppLog>> = repository.recentLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // AI Analysis Panel
    val aiExplanation = MutableStateFlow("")
    val isAiLoading = MutableStateFlow(false)

    // --- Interactive Tone Generator Trace Log ---
    // System News Feed Simulator
    val activeNewsCurrency = MutableStateFlow("USD")
    val activeNewsSeverity = MutableStateFlow("HIGH") // "HIGH", "MEDIUM", "NONE"

    private var tickJob: Job? = null
    private var autoTradeScanJob: Job? = null

    init {
        // Apply fallback dictionary language on load
        Loc.currentLanguage = appLanguage.value

        // Setup base chart loaded series
        resetMarketData()

        // Start Background Loops
        startTicks()
        startAutoTradeScanner()

        // Write launch log
        viewModelScope.launch {
            repository.addLog(Loc.get("log_start"), "INFO")
        }
    }

    private fun playTone(soundName: String, durationMs: Int = 120) {
        if (!soundEnabled.value) return
        viewModelScope.launch {
            repository.addLog("[SOUND SYSTEM] Played Sound effect: '$soundName' ($durationMs ms)", "INFO")
        }
    }

    fun changeLanguage(lang: Language) {
        appLanguage.value = lang
        Loc.currentLanguage = lang
        viewModelScope.launch {
            repository.addLog("Language changed to $lang / Язык изменен на $lang", "INFO")
        }
    }

    fun triggerNotification(title: String, msg: String, isWin: Boolean? = null) {
        if (!notificationsEnabled.value) return
        val item = NotificationMessage(title = title, message = msg, isWin = isWin)
        _notifications.update { (listOf(item) + it).take(5) }
    }

    fun dismissNotification(id: String) {
        _notifications.update { list -> list.filter { it.id != id } }
    }

    fun resetMarketData() {
        val pair = selectedPair.value
        marketSeed = Random.nextLong()
        val history = TradingEngine.generateHistoricalCandles(pair, marketSeed, 45)
        synchronized(candleMutex) {
            _candles.value = history
        }
        recalculateSignals()
    }

    fun updateSelectedPair(pair: String) {
        selectedPair.value = pair
        aiExplanation.value = ""
        resetMarketData()
        viewModelScope.launch {
            repository.addLog(Loc.get("log_manual_check").replace("{pair}", pair), "INFO")
        }
    }

    fun triggerManualAnalyze() {
        recalculateSignals()
        playTone("MANUAL_ANALYZE_BEEP", 150)
    }

    private fun recalculateSignals() {
        val list = _candles.value
        if (list.isEmpty()) return
        val currentResult = TradingEngine.analyze(
            pair = selectedPair.value,
            candles = list,
            timeframe = selectedCandleTimeframe.value,
            useTimeFilter = sessionFilterEnabled.value,
            useVolatilityFilter = volatilityFilterEnabled.value,
            useNewsFilter = newsFilterEnabled.value,
            onlyStrong = onlyStrongSignalsMode.value,
            newsImpactCurrency = activeNewsCurrency.value,
            newsImpactSeverity = activeNewsSeverity.value
        )
        _signalResult.value = currentResult
    }

    // Dynamic background simulation loops
    private fun startTicks() {
        tickJob?.cancel()
        tickJob = viewModelScope.launch {
            while (true) {
                delay(2000) // update asset rates every 2 seconds
                synchronized(candleMutex) {
                    _candles.value = TradingEngine.tickCandles(_candles.value, marketSeed)
                }
                recalculateSignals()
                tickActiveTrades()
                simulateNewsTick()
            }
        }
    }

    private fun simulateNewsTick() {
        // Randomly simulate macroeconomic news impacts for visual dynamics
        if (Random.nextInt(100) < 5) {
            val currencies = listOf("USD", "EUR", "GBP", "JPY", "CHF", "AUD", "CAD")
            val selected = currencies.random()
            val severity = listOf("HIGH", "MEDIUM", "NONE").random()
            activeNewsCurrency.value = selected
            activeNewsSeverity.value = severity
            if (severity == "HIGH" && newsFilterEnabled.value) {
                viewModelScope.launch {
                    val alert = Loc.get("news_impact_high").replace("{currency}", selected)
                    repository.addLog(alert, "WARNING")
                    triggerNotification("FxSignals NEWS", alert)
                    playTone("NEWS_IMPACT_PIP", 400)
                }
            }
        }
    }

    private fun startAutoTradeScanner() {
        autoTradeScanJob?.cancel()
        autoTradeScanJob = viewModelScope.launch {
            while (true) {
                delay(6000) // Scan for auto trades every 6 seconds
                if (isAutoTrading.value) {
                    processAutoTradingScan()
                }
            }
        }
    }

    private suspend fun processAutoTradingScan() {
        // Automatically checks a few pairs for triggers
        val targetPairs = TradingEngine.FOREX_PAIRS.shuffled().take(3)
        for (pair in targetPairs) {
            val randSeed = Random.nextLong()
            val dummyCandles = TradingEngine.generateHistoricalCandles(pair, randSeed, 40)
            val checkResult = TradingEngine.analyze(
                pair = pair,
                candles = dummyCandles,
                timeframe = selectedCandleTimeframe.value,
                useTimeFilter = sessionFilterEnabled.value,
                useVolatilityFilter = volatilityFilterEnabled.value,
                useNewsFilter = newsFilterEnabled.value,
                onlyStrong = onlyStrongSignalsMode.value,
                newsImpactCurrency = activeNewsCurrency.value,
                newsImpactSeverity = activeNewsSeverity.value
            )

            val systemLogMsg = Loc.get("log_auto_check")
                .replace("{pair}", pair)
                .replace("{signal}", checkResult.type.name)
            repository.addLog(systemLogMsg, "INFO")

            // Determine if we should open automatically
            if (checkResult.type != SignalType.NO_SIGNAL && checkResult.confidence >= probabilityThreshold.value) {
                // Check daily limits 
                val currentHist = tradeHistory.value
                val todayCount = currentHist.size // simple today count
                if (todayCount >= dailyLimitCount.value) {
                    repository.addLog(Loc.get("log_limit_hit"), "ERROR")
                    triggerNotification("[⚠️ RISK LIMIT]", Loc.get("log_limit_hit"))
                    playTone("RISK_LIMIT_ERROR", 200)
                    continue
                }

                // Check anti-streak loss protection
                if (antiLossStreakProtection.value && currentHist.size >= 3) {
                    val lastThree = currentHist.take(3)
                    val allLost = lastThree.all { it.result == "LOSS" }
                    if (allLost) {
                        repository.addLog("[RM] Auto-Trade Blocked: 3 loss series detected. Protecting capital.", "WARNING")
                        triggerNotification("[⚠️ RISK PROTECTION]", "Safe Mode activated: Trading series halt.")
                        playTone("STREAK_HALT_ERROR", 150)
                        continue
                    }
                }

                openTrade(pair, checkResult, isAuto = true)
                break // throttle to maximum 1 trade per scan cycle
            }
        }
    }

    fun openManualTrade() {
        val result = _signalResult.value
        if (result == null || result.type == SignalType.NO_SIGNAL) {
            triggerNotification("Error / Ошибка", "No strong signal available for entering!")
            playTone("NO_SIGNAL_ERROR", 150)
            return
        }
        viewModelScope.launch {
            openTrade(selectedPair.value, result, isAuto = false)
        }
    }

    private suspend fun openTrade(pair: String, signal: SignalResult, isAuto: Boolean) {
        val capBet = betSize.value
        if (balance.value < capBet) {
            repository.addLog("Insufficient Demo Capital! / Недостаточно средств на Демо-балансе!", "ERROR")
            triggerNotification("Alert", "Insufficient Demo capital. Please refill.")
            return
        }

        // deduct from balance
        balance.update { it - capBet }

        val sec = getDurationInSeconds(selectedTradeDuration.value)
        val tId = UUID.randomUUID().toString()
        val newPos = ActiveTrade(
            id = tId,
            pair = pair,
            entryPrice = signal.currentPrice,
            direction = signal.type.name,
            stake = capBet,
            durationText = selectedTradeDuration.value,
            totalSeconds = sec,
            secondsRemaining = sec,
            initialProbability = signal.confidence,
            isAuto = isAuto
        )

        _activeTrades.update { it + newPos }

        val logMsg = Loc.get("log_trade_open")
            .replace("{pair}", pair)
            .replace("{dir}", signal.type.name)
            .replace("{prob}", signal.confidence.toString())
            .replace("{bet}", capBet.toInt().toString())

        repository.addLog(logMsg, "SUCCESS")
        triggerNotification(Loc.get("app_title"), logMsg)
        playTone("TRADE_OPEN_ACK", 250)
    }

    private fun getDurationInSeconds(dur: String): Int {
        return when (dur) {
            "1m" -> 15 // sped up for rich active visual interaction from 60
            "2m" -> 30
            "3m" -> 45
            "4m" -> 60
            "5m" -> 75
            "10m" -> 120
            "15m" -> 180
            "30m" -> 300
            "1h" -> 600
            else -> 15
        }
    }

    private suspend fun tickActiveTrades() {
        val currentList = _activeTrades.value
        if (currentList.isEmpty()) return

        val updated = mutableListOf<ActiveTrade>()
        for (trade in currentList) {
            trade.secondsRemaining -= 2 // ticked every 2 seconds
            if (trade.secondsRemaining <= 0) {
                resolveFinishedTrade(trade)
            } else {
                updated.add(trade)
            }
        }
        _activeTrades.value = updated
    }

    private suspend fun resolveFinishedTrade(trade: ActiveTrade) {
        // Evaluate simulated outcome
        // Highly reliable: base the finish on entry probability or random weight!
        val didWin = Random.nextInt(100) < trade.initialProbability
        val profitRate = 0.85 // 85% payouts
        val payout = if (didWin) trade.stake * (1.0 + profitRate) else 0.0
        val profitLossValue = if (didWin) trade.stake * profitRate else -trade.stake

        // add payout back
        balance.update { it + payout }

        // Compile local reasons or language descriptions
        val localeReasons = if (appLanguage.value == Language.RU) {
            "Технический паттерн отработал штатно по направлению тренда."
        } else {
            "Simulated tech indicators aligned within probability bounds."
        }

        val completedTrade = com.example.database.Trade(
            pair = trade.pair,
            candleTimeframe = selectedCandleTimeframe.value,
            tradeDuration = trade.durationText,
            direction = trade.direction,
            probability = trade.initialProbability,
            result = if (didWin) "WIN" else "LOSS",
            profitLoss = profitLossValue,
            isAuto = trade.isAuto,
            reason = localeReasons
        )

        repository.insertTrade(completedTrade)

        val outcomeLog = if (didWin) {
            Loc.get("log_trade_success")
                .replace("{pair}", trade.pair)
                .replace("{profit}", (trade.stake * profitRate).toInt().toString())
        } else {
            Loc.get("log_trade_fail")
                .replace("{pair}", trade.pair)
                .replace("{bet}", trade.stake.toInt().toString())
        }

        repository.addLog(outcomeLog, if (didWin) "SUCCESS" else "WARNING")
        triggerNotification(
            title = if (didWin) "💰 PROFIT" else "📉 LOSS",
            msg = "${trade.pair} : ${trade.direction} / " + if (didWin) "+$${(trade.stake * profitRate).toInt()}" else "-$${trade.stake.toInt()}",
            isWin = didWin
        )

        // beep
        if (didWin) {
            playTone("PROFIT_BEACON", 300)
        } else {
            playTone("LOSS_DIAL", 400)
        }
    }

    fun requestAIEvaluation() {
        val signal = _signalResult.value ?: return
        isAiLoading.value = true
        aiExplanation.value = ""
        viewModelScope.launch {
            val response = GeminiAnalyzer.getAIRecommendation(
                pair = selectedPair.value,
                signalType = signal.type.name,
                confidence = signal.confidence,
                timeframe = selectedCandleTimeframe.value,
                rsi = signal.rsiVal,
                macd = signal.macdVal,
                currentPrice = signal.currentPrice,
                marketState = signal.marketState,
                lang = appLanguage.value.name
            )
            aiExplanation.value = response
            isAiLoading.value = false
        }
    }

    fun clearTradeHistory() {
        viewModelScope.launch {
            repository.clearAllTrades()
            repository.addLog("Trade history cleared / История очищена", "INFO")
        }
    }

    fun clearSystemLogs() {
        viewModelScope.launch {
            repository.clearLogs()
            repository.addLog("Logs cleared / Логи очищены", "INFO")
        }
    }

    fun refillDemoBalance() {
        balance.value = 10000.0
        triggerNotification("Demo Capital", "Demo Refill Success! $10,000 available.")
        playTone("DEMO_REFILL_BEEP", 100)
    }

    fun getExportCsvText(): String {
        val list = tradeHistory.value
        val sb = java.lang.StringBuilder()
        sb.append("ID,Timestamp,Pair,Timeframe,Duration,Direction,Confidence,Result,ProfitLoss,Mode\n")
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        list.forEach { t ->
            sb.append("${t.id},${sdf.format(Date(t.timestamp))},${t.pair},${t.candleTimeframe},${t.tradeDuration},${t.direction},${t.probability}%,${t.result},${t.profitLoss},${if (t.isAuto) "AUTO" else "MANUAL"}\n")
        }
        return sb.toString()
    }

    fun addSystemLog(message: String, level: String = "INFO") {
        viewModelScope.launch {
            repository.addLog(message, level)
        }
    }
}
