package com.example.database

import kotlinx.coroutines.flow.Flow

class TradeRepository(private val tradeDao: TradeDao) {

    val allTrades: Flow<List<Trade>> = tradeDao.getAllTrades()
    val recentLogs: Flow<List<AppLog>> = tradeDao.getRecentLogs()

    suspend fun insertTrade(trade: Trade) {
        tradeDao.insertTrade(trade)
    }

    suspend fun clearAllTrades() {
        tradeDao.clearAllTrades()
    }

    suspend fun addLog(message: String, level: String = "INFO") {
        tradeDao.insertLog(AppLog(message = message, level = level))
    }

    suspend fun clearLogs() {
        tradeDao.clearAllLogs()
    }
}
