package com.example.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "trades")
data class Trade(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val pair: String,
    val candleTimeframe: String,
    val tradeDuration: String,
    val direction: String, // "CALL", "PUT"
    val probability: Int,
    val result: String, // "WIN", "LOSS"
    val profitLoss: Double,
    val isAuto: Boolean,
    val reason: String
)

@Entity(tableName = "logs")
data class AppLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val message: String,
    val level: String // "INFO", "WARNING", "SUCCESS", "ERROR"
)

@Dao
interface TradeDao {
    @Query("SELECT * FROM trades ORDER BY timestamp DESC")
    fun getAllTrades(): Flow<List<Trade>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrade(trade: Trade)

    @Query("DELETE FROM trades")
    suspend fun clearAllTrades()

    @Query("SELECT * FROM logs ORDER BY timestamp DESC LIMIT 200")
    fun getRecentLogs(): Flow<List<AppLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: AppLog)

    @Query("DELETE FROM logs")
    suspend fun clearAllLogs()
}

@Database(entities = [Trade::class, AppLog::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun tradeDao(): TradeDao
}
