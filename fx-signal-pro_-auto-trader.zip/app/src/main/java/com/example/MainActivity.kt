package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.Room
import kotlinx.coroutines.flow.update
import com.example.viewmodel.TradingViewModel
import com.example.viewmodel.ActiveTrade
import androidx.lifecycle.viewModelScope
import com.example.database.AppDatabase
import com.example.database.Trade
import com.example.database.TradeRepository
import com.example.localization.Language
import com.example.localization.Loc
import com.example.trading.*
import com.example.ui.components.CandlestickChart
import com.example.ui.components.SystemNotificationBadge
import com.example.ui.components.TechnicalIndicatorOverview
import com.example.ui.theme.*
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Setup database and repository
        val database = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java, "fx_oracle.db"
        ).fallbackToDestructiveMigration().build()
        
        val repository = TradeRepository(database.tradeDao())
        
        // Define clean custom Factory
        val factory = object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                @Suppress("UNCHECKED_CAST")
                return TradingViewModel(repository) as T
            }
        }

        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val vm: TradingViewModel = viewModel(factory = factory)
                MainTradingScreen(viewModel = vm)
            }
        }
    }
}

enum class NavigationTab {
    TRADE, HISTORY, STATS, LOGS, SETTINGS
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainTradingScreen(viewModel: TradingViewModel) {
    val language by viewModel.appLanguage.collectAsStateWithLifecycle()
    val activeTab = remember { mutableStateOf(NavigationTab.TRADE) }
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val balance by viewModel.balance.collectAsStateWithLifecycle()
    val isAutoTrading by viewModel.isAutoTrading.collectAsStateWithLifecycle()

    // Correct translation context update
    Loc.currentLanguage = language

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .background(
                                    Brush.linearGradient(listOf(DarkPrimary, DarkSecondary)),
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.TrendingUp,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = Loc.get("app_title"),
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.SansSerif,
                            color = TextWhite,
                            fontSize = 20.sp
                        )
                    }
                },
                actions = {
                    // Demo Account Balance Badge
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CardSurfaceHover),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .clickable { viewModel.refillDemoBalance() }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "DEMO",
                                fontSize = 10.sp,
                                color = AccentGold,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(end = 4.dp)
                            )
                            Text(
                                text = "$${String.format("%,.0f", balance)}",
                                color = CallGreen,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DeepSpaceBg
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = DeepSpaceBg,
                tonalElevation = 8.dp
            ) {
                listOf(
                    NavigationTab.TRADE to Icons.Default.ShowChart,
                    NavigationTab.HISTORY to Icons.Default.History,
                    NavigationTab.STATS to Icons.Default.PieChart,
                    NavigationTab.LOGS to Icons.Default.ListAlt,
                    NavigationTab.SETTINGS to Icons.Default.Settings
                ).forEach { (tab, icon) ->
                    val isSelected = activeTab.value == tab
                    val labelKey = when (tab) {
                        NavigationTab.TRADE -> "tab_trade"
                        NavigationTab.HISTORY -> "tab_history"
                        NavigationTab.STATS -> "tab_stats"
                        NavigationTab.LOGS -> "tab_logs"
                        NavigationTab.SETTINGS -> "tab_settings"
                    }
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { activeTab.value = tab },
                        icon = {
                            Icon(
                                imageVector = icon,
                                contentDescription = Loc.get(labelKey),
                                tint = if (isSelected) DarkSecondary else TextMuted
                            )
                        },
                        label = {
                            Text(
                                text = Loc.get(labelKey),
                                color = if (isSelected) TextWhite else TextMuted,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = CardSurfaceHover
                        )
                    )
                }
            }
        },
        containerColor = DeepSpaceBg
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Screen switching with scroll support
            when (activeTab.value) {
                NavigationTab.TRADE -> TradeScreen(viewModel)
                NavigationTab.HISTORY -> HistoryScreen(viewModel)
                NavigationTab.STATS -> StatsScreen(viewModel)
                NavigationTab.LOGS -> LogsScreen(viewModel)
                NavigationTab.SETTINGS -> SettingsScreen(viewModel)
            }

            // Floated Dynamic System Toast Overlay
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                notifications.forEach { item ->
                    SystemNotificationBadge(
                        notify = item,
                        onDismiss = { viewModel.dismissNotification(item.id) }
                    )
                }
            }
        }
    }
}

@Composable
fun TradeScreen(viewModel: TradingViewModel) {
    val candles by viewModel.candles.collectAsStateWithLifecycle()
    val signalResult by viewModel.signalResult.collectAsStateWithLifecycle()
    val activeTrades by viewModel.activeTrades.collectAsStateWithLifecycle()
    
    val selectedPair by viewModel.selectedPair.collectAsStateWithLifecycle()
    val selectedCandleTf by viewModel.selectedCandleTimeframe.collectAsStateWithLifecycle()
    val selectedTradeDur by viewModel.selectedTradeDuration.collectAsStateWithLifecycle()
    
    val isAutoTrading by viewModel.isAutoTrading.collectAsStateWithLifecycle()
    val aiExplanation by viewModel.aiExplanation.collectAsStateWithLifecycle()
    val isAiLoading by viewModel.isAiLoading.collectAsStateWithLifecycle()

    var showPairSelector by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(4.dp)) }

        // Pair Selector & Quick Setup Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardSurface),
                border = BorderStroke(1.dp, BorderColor),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(Loc.get("lbl_pair"), color = TextMuted, fontSize = 11.sp)
                            Text(
                                text = selectedPair,
                                color = TextWhite,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.clickable { showPairSelector = true }
                            )
                        }

                        Button(
                            onClick = { showPairSelector = true },
                            colors = ButtonDefaults.buttonColors(containerColor = CardSurfaceHover)
                        ) {
                            Text("CHANGE", color = AccentGold, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (showPairSelector) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("SELECT FOREX CAPITAL PAIR:", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(6.dp))
                        
                        // Scrollable row of pairs
                        Row(
                            modifier = Modifier
                                .horizontalScroll(rememberScrollState())
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            TradingEngine.FOREX_PAIRS.forEach { pairOption ->
                                val active = pairOption == selectedPair
                                Box(
                                    modifier = Modifier
                                        .background(
                                            if (active) DarkSecondary else CardSurfaceHover,
                                            RoundedCornerShape(8.dp)
                                        )
                                        .border(
                                            1.dp,
                                            if (active) AccentGold else BorderColor,
                                            RoundedCornerShape(8.dp)
                                        )
                                        .clickable {
                                            viewModel.updateSelectedPair(pairOption)
                                            showPairSelector = false
                                        }
                                        .padding(horizontal = 12.dp, vertical = 8.dp)
                                ) {
                                    Text(
                                        text = pairOption,
                                        color = if (active) Color.Black else TextWhite,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = BorderColor)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Dual Options selectors - Candle TF and Duration TF
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(Loc.get("lbl_candle"), color = TextMuted, fontSize = 11.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                listOf("1m", "2m", "3m", "5m").forEach { tf ->
                                    val isSel = tf == selectedCandleTf
                                    Box(
                                        modifier = Modifier
                                            .size(34.dp)
                                            .background(
                                                if (isSel) DarkPrimary else CardSurfaceHover,
                                                CircleShape
                                            )
                                            .clickable {
                                                viewModel.selectedCandleTimeframe.value = tf
                                                viewModel.resetMarketData()
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(tf, color = TextWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        Column(modifier = Modifier.weight(1.2f), horizontalAlignment = Alignment.End) {
                            Text(Loc.get("lbl_duration"), color = TextMuted, fontSize = 11.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                listOf("1m", "5m", "15m", "1h").forEach { dur ->
                                    val isSel = dur == selectedTradeDur
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                if (isSel) DarkPrimary else CardSurfaceHover,
                                                RoundedCornerShape(6.dp)
                                            )
                                            .border(1.dp, BorderColor, RoundedCornerShape(6.dp))
                                            .clickable { viewModel.selectedTradeDuration.value = dur }
                                            .padding(horizontal = 8.dp, vertical = 6.dp)
                                    ) {
                                        Text(dur, color = TextWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Beautiful live candlestick chart
        item {
            CandlestickChart(
                candles = candles,
                signalResult = signalResult,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
            )
        }

        // Active State Mode Header / Auto trade warning banner
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isAutoTrading) DarkSecondary.copy(alpha = 0.15f) else CardSurface
                ),
                border = BorderStroke(
                    1.dp,
                    if (isAutoTrading) DarkSecondary.copy(alpha = 0.5f) else BorderColor
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .background(
                                    if (isAutoTrading) CallGreen else AccentGold,
                                    CircleShape
                                )
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (isAutoTrading) Loc.get("autotrade_active") else Loc.get("autotrade_inactive"),
                            color = if (isAutoTrading) CallGreen else TextWhite,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 12.sp
                        )
                    }

                    Switch(
                        checked = isAutoTrading,
                        onCheckedChange = { viewModel.isAutoTrading.value = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = CallGreen,
                            checkedTrackColor = CardSurfaceHover
                        )
                    )
                }
            }
        }

        // Signal confidence assessment card
        item {
            val signal = signalResult
            if (signal != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardSurface),
                    border = BorderStroke(
                        2.dp,
                        when (signal.type) {
                            SignalType.CALL -> CallGreen
                            SignalType.PUT -> PutRed
                            SignalType.NO_SIGNAL -> BorderColor
                        }
                    ),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = when (signal.type) {
                                        SignalType.CALL -> Loc.get("direction_call")
                                        SignalType.PUT -> Loc.get("direction_put")
                                        SignalType.NO_SIGNAL -> Loc.get("direction_nosignal")
                                    },
                                    color = when (signal.type) {
                                        SignalType.CALL -> CallGreen
                                        SignalType.PUT -> PutRed
                                        SignalType.NO_SIGNAL -> TextMuted
                                    },
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 18.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = Loc.get("lbl_probability") + ": ${signal.confidence}%",
                                    color = TextWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }

                            // Dynamic Confidence Gauge Ring
                            Box(
                                modifier = Modifier.size(48.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(
                                    progress = signal.confidence / 100f,
                                    color = if (signal.confidence >= 75) CallGreen else TextMuted,
                                    strokeWidth = 6.dp,
                                    modifier = Modifier.fillMaxSize(),
                                    trackColor = BorderColor
                                )
                                Text(
                                    text = "${signal.confidence}%",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Divider(color = BorderColor)
                        Spacer(modifier = Modifier.height(12.dp))

                        // Trigger actions
                        Text(Loc.get("lbl_reasons"), color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        
                        for (rKey in signal.reasons) {
                            Row(
                                modifier = Modifier.padding(vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = if (signal.type == SignalType.CALL) CallGreen else PutRed,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(Loc.get(rKey), color = TextWhite, fontSize = 12.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Buttons Grid
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Exec Manual Option Trade
                            Button(
                                onClick = { viewModel.openManualTrade() },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = when (signal.type) {
                                        SignalType.CALL -> CallGreen
                                        SignalType.PUT -> PutRed
                                        SignalType.NO_SIGNAL -> CardSurfaceHover
                                    }
                                ),
                                enabled = signal.type != SignalType.NO_SIGNAL
                            ) {
                                Text(
                                    text = if (signal.type == SignalType.CALL) "EXEC CALL" else if (signal.type == SignalType.PUT) "EXEC PUT" else "NO SIGNAL ENTRY",
                                    fontWeight = FontWeight.Bold,
                                    color = if (signal.type == SignalType.NO_SIGNAL) TextMuted else Color.Black
                                )
                            }

                            // Query Gemini AI analysis button
                            OutlinedButton(
                                onClick = { viewModel.requestAIEvaluation() },
                                modifier = Modifier.weight(1f),
                                border = BorderStroke(1.dp, AccentGold)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = AccentGold,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("ASK AI", color = AccentGold, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Animated Gemini AI results console panel
        if (isAiLoading || aiExplanation.isNotEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardSurface),
                    border = BorderStroke(1.dp, AccentGold.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = AccentGold,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = Loc.get("ai_expl_general"),
                                color = TextWhite,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Divider(color = BorderColor)
                        Spacer(modifier = Modifier.height(10.dp))

                        if (isAiLoading) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(100.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    CircularProgressIndicator(color = AccentGold)
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(Loc.get("ai_expl_loading"), color = TextMuted, fontSize = 12.sp)
                                }
                            }
                        } else {
                            Text(
                                text = aiExplanation,
                                color = TextWhite,
                                fontSize = 13.sp,
                                lineHeight = 18.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Oscillators indicators summary gauge list
        item {
            TechnicalIndicatorOverview(result = signalResult)
        }

        // Active Trades Progress Lists
        if (activeTrades.isNotEmpty()) {
            item {
                Text(
                    text = Loc.get("lbl_active_trades").uppercase(),
                    color = AccentGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            items(activeTrades) { tr ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardSurface),
                    border = BorderStroke(
                        1.dp,
                        if (tr.direction == "CALL") CallGreen.copy(alpha = 0.5f) else PutRed.copy(alpha = 0.5f)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(tr.pair, fontWeight = FontWeight.Bold, color = TextWhite)
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .background(
                                            if (tr.direction == "CALL") CallGreen.copy(alpha = 0.15f) else PutRed.copy(
                                                alpha = 0.15f
                                            ),
                                            RoundedCornerShape(4.dp)
                                        )
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        tr.direction,
                                        color = if (tr.direction == "CALL") CallGreen else PutRed,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Entry: ${String.format("%.5f", tr.entryPrice)} • capital $${tr.stake.toInt()}",
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                        }

                        // Timer Count down
                        Box(
                            modifier = Modifier
                                .background(CardSurfaceHover, RoundedCornerShape(8.dp))
                                .border(1.dp, BorderColor, RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${tr.secondsRemaining}s",
                                color = AccentGold,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
    }
}

@Composable
fun HistoryScreen(viewModel: TradingViewModel) {
    val history by viewModel.tradeHistory.collectAsStateWithLifecycle()
    var searchStr by remember { mutableStateOf("") }
    var resultFilter by remember { mutableStateOf("ALL") } // "ALL", "WIN", "LOSS"
    var sortBy by remember { mutableStateOf("DATE") } // "DATE", "PAIR", "PROFIT"

    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        // Search and Actions row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextField(
                value = searchStr,
                onValueChange = { searchStr = it },
                placeholder = { Text(Loc.get("search_hint"), color = TextMuted) },
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp)),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = CardSurface,
                    unfocusedContainerColor = CardSurface,
                    disabledContainerColor = CardSurface,
                    focusedTextColor = TextWhite,
                    unfocusedTextColor = TextWhite,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                maxLines = 1,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text)
            )

            // Export CSV
            IconButton(
                onClick = {
                    val csvText = viewModel.getExportCsvText()
                    // simulated export to notification
                    viewModel.triggerNotification("CSV EXPORT", "CSV code printed in developer logs panel.")
                    viewModel.addSystemLog("CSV EXPORT: \n$csvText", "INFO")
                },
                modifier = Modifier.background(CardSurfaceHover, CircleShape)
            ) {
                Icon(imageVector = Icons.Default.FileDownload, contentDescription = "Export CSV", tint = AccentGold)
            }

            // Clear historical records
            IconButton(
                onClick = { viewModel.clearTradeHistory() },
                modifier = Modifier.background(CardSurfaceHover, CircleShape)
            ) {
                Icon(imageVector = Icons.Default.Delete, contentDescription = "Purge", tint = PutRed)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Small Row of filter buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("ALL" to "all", "WIN" to "wins", "LOSS" to "losses").forEach { (v, key) ->
                val chosen = resultFilter == v
                AssistChip(
                    onClick = { resultFilter = v },
                    label = { Text(Loc.get(key), color = if (chosen) Color.Black else TextWhite) },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = if (chosen) DarkSecondary else CardSurface
                    ),
                    border = BorderStroke(1.dp, if (chosen) AccentGold else BorderColor)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        val sdf = SimpleDateFormat("HH:mm:ss dd.MM", Locale.getDefault())

        val filtered = history.filter {
            (it.pair.contains(searchStr, ignoreCase = true)) &&
            (resultFilter == "ALL" || it.result == resultFilter)
        }.sortedWith { a, b ->
            when (sortBy) {
                "PAIR" -> a.pair.compareTo(b.pair)
                "PROFIT" -> b.profitLoss.compareTo(a.profitLoss)
                else -> b.timestamp.compareTo(a.timestamp) // DATE DSC
            }
        }

        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(Loc.get("empty_history"), color = TextMuted, textAlign = TextAlign.Center)
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filtered) { item ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CardSurface),
                        border = BorderStroke(1.dp, BorderColor),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = item.pair,
                                        fontWeight = FontWeight.Bold,
                                        color = TextWhite,
                                        fontSize = 15.sp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                if (item.result == "WIN") CallGreen.copy(alpha = 0.15f) else PutRed.copy(
                                                    alpha = 0.15f
                                                ),
                                                RoundedCornerShape(4.dp)
                                            )
                                            .padding(horizontal = 4.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = item.result,
                                            color = if (item.result == "WIN") CallGreen else PutRed,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }

                                    if (item.isAuto) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Box(
                                            modifier = Modifier
                                                .background(AccentGold.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                                .padding(horizontal = 4.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                "AUTO",
                                                color = AccentGold,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }

                                Text(
                                    text = (if (item.profitLoss > 0) "+$" else "-$") + String.format("%.0f", Math.abs(item.profitLoss)),
                                    color = if (item.result == "WIN") CallGreen else PutRed,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${item.candleTimeframe} Candle • ${item.tradeDuration} Dur • conf ${item.probability}%",
                                    fontSize = 11.sp,
                                    color = TextMuted
                                )
                                Text(
                                    text = sdf.format(Date(item.timestamp)),
                                    fontSize = 11.sp,
                                    color = TextMuted
                                )
                            }
                        }
                    }
                }
                item { Spacer(modifier = Modifier.height(16.dp)) }
            }
        }
    }
}

@Composable
fun StatsScreen(viewModel: TradingViewModel) {
    val history by viewModel.tradeHistory.collectAsStateWithLifecycle()

    val totalCount = history.size
    val winsCount = history.count { it.result == "WIN" }
    val lossesCount = history.count { it.result == "LOSS" }
    val winrate = if (totalCount > 0) (winsCount.toDouble() / totalCount.toDouble() * 100).toInt() else 0

    val bestPerformingPair = if (history.isNotEmpty()) {
        history.filter { it.result == "WIN" }
            .groupBy { it.pair }
            .maxByOrNull { it.value.size }?.key ?: "EUR/USD"
    } else {
        "EUR/USD"
    }

    val bestTf = if (history.isNotEmpty()) {
        history.filter { it.result == "WIN" }
            .groupBy { it.candleTimeframe }
            .maxByOrNull { it.value.size }?.key ?: "1m"
    } else {
        "1m"
    }

    val averageConfidence = if (history.isNotEmpty()) {
        history.map { it.probability }.average().toInt()
    } else {
        0
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(4.dp)) }

        // Large Premium Win Rate gauge circle card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardSurface),
                border = BorderStroke(1.dp, BorderColor),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = Loc.get("stats_winrate").uppercase(),
                        color = TextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Box(
                        modifier = Modifier.size(130.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(
                            progress = winrate / 100f,
                            color = if (winrate >= 60) CallGreen else AccentGold,
                            strokeWidth = 14.dp,
                            modifier = Modifier.fillMaxSize(),
                            trackColor = BorderColor
                        )

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "$winrate%",
                                fontSize = 32.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextWhite
                            )
                            Text(
                                text = "ACCURACY",
                                fontSize = 9.sp,
                                color = TextMuted,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Aggregate Grid statistics
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardSurface),
                    modifier = Modifier.weight(1f),
                    border = BorderStroke(1.dp, BorderColor)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(Loc.get("stats_wins"), color = TextMuted, fontSize = 11.sp)
                        Text(
                            text = winsCount.toString(),
                            color = CallGreen,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = CardSurface),
                    modifier = Modifier.weight(1f),
                    border = BorderStroke(1.dp, BorderColor)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(Loc.get("stats_losses"), color = TextMuted, fontSize = 11.sp)
                        Text(
                            text = lossesCount.toString(),
                            color = PutRed,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = CardSurface),
                    modifier = Modifier.weight(1f),
                    border = BorderStroke(1.dp, BorderColor)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(Loc.get("stats_total"), color = TextMuted, fontSize = 11.sp)
                        Text(
                            text = totalCount.toString(),
                            color = TextWhite,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Secondary Insight card list
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardSurface),
                border = BorderStroke(1.dp, BorderColor),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("STRATEGY PERFORMANCE", fontWeight = FontWeight.Bold, color = AccentGold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = BorderColor)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(Loc.get("stats_best_pair"), color = TextMuted, fontSize = 12.sp)
                        Text(bestPerformingPair, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(Loc.get("stats_best_tf"), color = TextMuted, fontSize = 12.sp)
                        Text(bestTf, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(Loc.get("stats_best_hour"), color = TextMuted, fontSize = 12.sp)
                        val utcHourString = "${(System.currentTimeMillis() / 3600000 % 24).toInt()}:00 UTC"
                        Text(utcHourString, color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(Loc.get("stats_avg_prob"), color = TextMuted, fontSize = 12.sp)
                        Text("$averageConfidence%", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
    }
}

@Composable
fun LogsScreen(viewModel: TradingViewModel) {
    val logs by viewModel.logs.collectAsStateWithLifecycle()
    val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("TELEMETRY LOGGER STREAM", color = AccentGold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Button(
                onClick = { viewModel.clearSystemLogs() },
                colors = ButtonDefaults.buttonColors(containerColor = CardSurfaceHover)
            ) {
                Text("CLEAR LOGS", color = PutRed, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (logs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text("No active trace logs found.", color = TextMuted)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .background(CardSurface, RoundedCornerShape(12.dp))
                    .border(1.dp, BorderColor, RoundedCornerShape(12.dp))
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(logs) { log ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                    ) {
                        Text(
                            text = "[${sdf.format(Date(log.timestamp))}]",
                            color = AccentGold,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(end = 6.dp)
                        )
                        Text(
                            text = log.message,
                            color = when (log.level) {
                                "SUCCESS" -> CallGreen
                                "WARNING" -> AccentGold
                                "ERROR" -> PutRed
                                else -> TextWhite
                            },
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: TradingViewModel) {
    val language by viewModel.appLanguage.collectAsStateWithLifecycle()
    val probabilityThreshold by viewModel.probabilityThreshold.collectAsStateWithLifecycle()
    val soundEnabled by viewModel.soundEnabled.collectAsStateWithLifecycle()
    val notificationsEnabled by viewModel.notificationsEnabled.collectAsStateWithLifecycle()
    val onlyStrongSignalsMode by viewModel.onlyStrongSignalsMode.collectAsStateWithLifecycle()
    
    val betValue by viewModel.betSize.collectAsStateWithLifecycle()
    val dailyLimitCount by viewModel.dailyLimitCount.collectAsStateWithLifecycle()
    val dailyLossLimit by viewModel.dailyLossLimit.collectAsStateWithLifecycle()
    val antiLossStreakProtection by viewModel.antiLossStreakProtection.collectAsStateWithLifecycle()

    val sessionFilterEnabled by viewModel.sessionFilterEnabled.collectAsStateWithLifecycle()
    val volatilityFilterEnabled by viewModel.volatilityFilterEnabled.collectAsStateWithLifecycle()
    val newsFilterEnabled by viewModel.newsFilterEnabled.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(4.dp)) }

        // Core Language Settings Section
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardSurface),
                border = BorderStroke(1.dp, BorderColor),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(Loc.get("cfg_lang"), fontWeight = FontWeight.Bold, color = AccentGold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = { viewModel.changeLanguage(Language.RU) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (language == Language.RU) DarkPrimary else CardSurfaceHover
                            )
                        ) {
                            Text("РУССКИЙ", color = TextWhite, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { viewModel.changeLanguage(Language.EN) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (language == Language.EN) DarkPrimary else CardSurfaceHover
                            )
                        ) {
                            Text("ENGLISH", color = TextWhite, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Trading Filters Preferences Section
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardSurface),
                border = BorderStroke(1.dp, BorderColor),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("STRATEGY ENTRY FILTERS", fontWeight = FontWeight.Bold, color = AccentGold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(Loc.get("filter_time"), color = TextWhite, fontSize = 13.sp)
                        Switch(
                            checked = sessionFilterEnabled,
                            onCheckedChange = { viewModel.sessionFilterEnabled.value = it }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(Loc.get("filter_volatility"), color = TextWhite, fontSize = 13.sp)
                        Switch(
                            checked = volatilityFilterEnabled,
                            onCheckedChange = { viewModel.volatilityFilterEnabled.value = it }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(Loc.get("filter_news"), color = TextWhite, fontSize = 13.sp)
                        Switch(
                            checked = newsFilterEnabled,
                            onCheckedChange = { viewModel.newsFilterEnabled.value = it }
                        )
                    }
                }
            }
        }

        // Risk parameters Section
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardSurface),
                border = BorderStroke(1.dp, BorderColor),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("CAPITAL RISK MANAGEMENT", fontWeight = FontWeight.Bold, color = AccentGold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(10.dp))

                    // Bet size slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(Loc.get("cfg_bet"), color = TextWhite, fontSize = 13.sp)
                        Text("$${betValue.toInt()}", color = AccentGold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Slider(
                        value = betValue.toFloat(),
                        onValueChange = { viewModel.betSize.value = it.toDouble() },
                        valueRange = 10f..1000f,
                        steps = 99,
                        colors = SliderDefaults.colors(thumbColor = AccentGold, activeTrackColor = AccentGold)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Confidence Threshold Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(Loc.get("cfg_threshold"), color = TextWhite, fontSize = 13.sp)
                        Text("$probabilityThreshold%", color = AccentGold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Slider(
                        value = probabilityThreshold.toFloat(),
                        onValueChange = { viewModel.probabilityThreshold.value = it.toInt() },
                        valueRange = 75f..99f,
                        steps = 24,
                        colors = SliderDefaults.colors(thumbColor = AccentGold, activeTrackColor = AccentGold)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(Loc.get("cfg_only_strong"), color = TextWhite, fontSize = 13.sp)
                        Switch(
                            checked = onlyStrongSignalsMode,
                            onCheckedChange = { viewModel.onlyStrongSignalsMode.value = it }
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Divider(color = BorderColor)
                    Spacer(modifier = Modifier.height(10.dp))

                    // Loss streak protection
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(Loc.get("cfg_anti_streak"), color = TextWhite, fontSize = 13.sp)
                        Switch(
                            checked = antiLossStreakProtection,
                            onCheckedChange = { viewModel.antiLossStreakProtection.value = it }
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Limits count inputs
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(Loc.get("cfg_limit_day"), color = TextWhite, fontSize = 13.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { viewModel.dailyLimitCount.update { (it - 5).coerceAtLeast(5) } }) {
                                Icon(imageVector = Icons.Default.Remove, contentDescription = "Decrease", tint = TextWhite)
                            }
                            Text(dailyLimitCount.toString(), color = TextWhite, fontWeight = FontWeight.Bold)
                            IconButton(onClick = { viewModel.dailyLimitCount.update { (it + 5).coerceAtMost(100) } }) {
                                Icon(imageVector = Icons.Default.Add, contentDescription = "Increase", tint = TextWhite)
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(Loc.get("cfg_limit_loss"), color = TextWhite, fontSize = 13.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { viewModel.dailyLossLimit.update { (it - 250.0).coerceAtLeast(250.0) } }) {
                                Icon(imageVector = Icons.Default.Remove, contentDescription = "Decrease", tint = TextWhite)
                            }
                            Text("$${dailyLossLimit.toInt()}", color = TextWhite, fontWeight = FontWeight.Bold)
                            IconButton(onClick = { viewModel.dailyLossLimit.update { (it + 250.0).coerceAtMost(5000.0) } }) {
                                Icon(imageVector = Icons.Default.Add, contentDescription = "Increase", tint = TextWhite)
                            }
                        }
                    }
                }
            }
        }

        // Notification preferences Settings Section
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardSurface),
                border = BorderStroke(1.dp, BorderColor),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("SYSTEM FEEDBACK SETTINGS", fontWeight = FontWeight.Bold, color = AccentGold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(Loc.get("cfg_sound"), color = TextWhite, fontSize = 13.sp)
                        Switch(
                            checked = soundEnabled,
                            onCheckedChange = { viewModel.soundEnabled.value = it }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(Loc.get("cfg_push"), color = TextWhite, fontSize = 13.sp)
                        Switch(
                            checked = notificationsEnabled,
                            onCheckedChange = { viewModel.notificationsEnabled.value = it }
                        )
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
    }
}
