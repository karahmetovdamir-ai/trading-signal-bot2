package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Cyberpunk Dark Trading Palette
val DeepSpaceBg = Color(0xFF0F111A)
val CardSurface = Color(0xFF161A26)
val CardSurfaceHover = Color(0xFF1E2436)

val CallGreen = Color(0xFF00E676)
val PutRed = Color(0xFFFF3D00)
val NoSignalGrey = Color(0xFF78909C)

val AccentGold = Color(0xFF00E5FF) // Electric Teal / Neon Aqua
val BorderColor = Color(0xFF262E45)

val TextWhite = Color(0xFFFFFFFF)
val TextMuted = Color(0xFF90A4AE)

val DarkPrimary = Color(0xFF2979FF)
val DarkSecondary = Color(0xFF00E5FF)
val DarkBackground = Color(0xFF0B0D14)
