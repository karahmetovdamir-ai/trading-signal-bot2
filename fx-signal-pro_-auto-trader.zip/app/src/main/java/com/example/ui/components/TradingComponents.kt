package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.Loc
import com.example.trading.Candle
import com.example.trading.SignalResult
import com.example.trading.SignalType
import com.example.ui.theme.*

@Composable
fun CandlestickChart(
    candles: List<Candle>,
    signalResult: SignalResult?,
    modifier: Modifier = Modifier
) {
    if (candles.isEmpty()) {
        Box(
            modifier = modifier.background(CardSurface, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = DarkSecondary)
        }
        return
    }

    val visibleCandles = candles.takeLast(30)
    val highestHigh = visibleCandles.maxOf { it.high }
    val lowestLow = visibleCandles.minOf { it.low }
    
    // Add 10% vertical pad
    val pad = (highestHigh - lowestLow) * 0.1
    val minVal = lowestLow - pad
    val maxVal = highestHigh + pad
    val range = maxVal - minVal

    Box(
        modifier = modifier
            .background(CardSurface, RoundedCornerShape(16.dp))
            .border(1.dp, BorderColor, RoundedCornerShape(16.dp))
            .padding(8.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // 1. Draw Background Grid Lines
            val gridLinesCount = 4
            for (i in 1..gridLinesCount) {
                val y = height * (i.toFloat() / (gridLinesCount + 1))
                drawLine(
                    color = BorderColor.copy(alpha = 0.5f),
                    start = Offset(0f, y),
                    end = Offset(width, y),
                    strokeWidth = 1f
                )
            }

            val stepX = width / visibleCandles.size
            val candleWidth = stepX * 0.65f

            // Helper to get Y coordinate based on price
            fun getY(price: Double): Float {
                if (range == 0.0) return height / 2
                return (height - ((price - minVal) / range * height)).toFloat()
            }

            // 2. Draw Bollinger Bands Lines if signalResult is active
            if (signalResult != null) {
                val upperPath = androidx.compose.ui.graphics.Path()
                val lowerPath = androidx.compose.ui.graphics.Path()

                visibleCandles.forEachIndexed { index, cd ->
                    // Since we simulate bands, let's trace dynamic offsets
                    val bandSpread = (maxVal - minVal) * 0.15
                    val mid = cd.close
                    val up = mid + bandSpread
                    val low = mid - bandSpread

                    val x = index * stepX + stepX / 2f
                    val yUp = getY(up)
                    val yLow = getY(low)

                    if (index == 0) {
                        upperPath.moveTo(x, yUp)
                        lowerPath.moveTo(x, yLow)
                    } else {
                        upperPath.lineTo(x, yUp)
                        lowerPath.lineTo(x, yLow)
                    }
                }

                drawPath(
                    path = upperPath,
                    color = DarkSecondary.copy(alpha = 0.35f),
                    style = Stroke(
                        width = 2.5f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                    )
                )

                drawPath(
                    path = lowerPath,
                    color = DarkSecondary.copy(alpha = 0.35f),
                    style = Stroke(
                        width = 2.5f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                    )
                )
            }

            // 3. Draw Candlesticks and Wicks
            visibleCandles.forEachIndexed { index, candle ->
                val x = index * stepX + stepX / 2f
                val yOpen = getY(candle.open)
                val yClose = getY(candle.close)
                val yHigh = getY(candle.high)
                val yLow = getY(candle.low)

                val isGreen = candle.close >= candle.open
                val color = if (isGreen) CallGreen else PutRed

                // Wick
                drawLine(
                    color = color,
                    start = Offset(x, yHigh),
                    end = Offset(x, yLow),
                    strokeWidth = 4f
                )

                // Body Rect
                val topRect = minOf(yOpen, yClose)
                val bottomRect = maxOf(yOpen, yClose)
                val rectHeight = maxOf(bottomRect - topRect, 4f) // make sure at least 4px visible

                drawRect(
                    color = color,
                    topLeft = Offset(x - candleWidth / 2f, topRect),
                    size = Size(candleWidth, rectHeight)
                )
            }

            // 4. Draw Spot Rate Current Indicator Line
            val currentPrice = visibleCandles.last().close
            val ySpot = getY(currentPrice)
            drawLine(
                color = AccentGold.copy(alpha = 0.8f),
                start = Offset(0f, ySpot),
                end = Offset(width, ySpot),
                strokeWidth = 3f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 10f), 0f)
            )
        }

        // Live Rate Floating Badge Top Right
        val lastPrice = visibleCandles.lastOrNull()?.close ?: 0.0
        val isUp = visibleCandles.size >= 2 && lastPrice >= visibleCandles[visibleCandles.size - 2].close
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(8.dp)
                .background(AccentGold.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                .border(1.dp, AccentGold.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Text(
                text = String.format("%.5f", lastPrice),
                color = if (isUp) CallGreen else PutRed,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }
    }
}

@Composable
fun TechnicalIndicatorOverview(
    result: SignalResult?,
    modifier: Modifier = Modifier
) {
    if (result == null) return

    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = CardSurface),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedTarget(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Oscillators & Indicators",
                    color = TextMuted,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
                Box(
                    modifier = Modifier
                        .background(AccentGold.copy(alpha = 0.12f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = Loc.get(result.marketState),
                        color = AccentGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Divider(color = BorderColor)

            // RSI Progress Indicator
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("RSI (14)", color = TextWhite, fontSize = 12.sp)
                    Text(
                        text = "${String.format("%.1f", result.rsiVal)} ${
                            when {
                                result.rsiVal > 70 -> "(Overbought)"
                                result.rsiVal < 30 -> "(Oversold)"
                                else -> "(Neutral)"
                            }
                        }",
                        color = if (result.rsiVal > 70) PutRed else if (result.rsiVal < 30) CallGreen else TextMuted,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = (result.rsiVal / 100f).toFloat(),
                    modifier = Modifier.fillMaxWidth(),
                    color = if (result.rsiVal > 70) PutRed else if (result.rsiVal < 30) CallGreen else DarkSecondary,
                    trackColor = BorderColor
                )
            }

            // MACD indicator reading
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("MACD Trend Index", color = TextWhite, fontSize = 12.sp)
                Text(
                    text = String.format("%.5f", result.macdVal),
                    color = if (result.macdVal > 0) CallGreen else PutRed,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Custom Bollinger testing bounds
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Bollinger Bands test", color = TextWhite, fontSize = 12.sp)
                val testRes = when {
                    result.currentPrice > result.bbandUpper -> "Upper Band test (PUT Edge)"
                    result.currentPrice < result.bbandLower -> "Lower Band test (CALL Edge)"
                    else -> "Safe Channel"
                }
                Text(
                    text = testRes,
                    color = if (result.currentPrice > result.bbandUpper) PutRed else if (result.currentPrice < result.bbandLower) CallGreen else TextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

private fun Arrangement.spacedTarget(dp: androidx.compose.ui.unit.Dp) = Arrangement.spacedBy(dp)

@Composable
fun SystemNotificationBadge(
    notify: com.example.viewmodel.NotificationMessage,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onDismiss() },
        colors = CardDefaults.cardColors(
            containerColor = when (notify.isWin) {
                true -> CallGreen.copy(alpha = 0.15f)
                false -> PutRed.copy(alpha = 0.15f)
                else -> CardSurface
            }
        ),
        border = BorderStroke(
            1.dp,
            when (notify.isWin) {
                true -> CallGreen.copy(alpha = 0.4f)
                false -> PutRed.copy(alpha = 0.4f)
                else -> AccentGold.copy(alpha = 0.4f)
            }
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = null,
                tint = when (notify.isWin) {
                    true -> CallGreen
                    false -> PutRed
                    else -> AccentGold
                },
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = notify.title,
                    color = TextWhite,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.sp
                )
                Text(
                    text = notify.message,
                    color = TextMuted,
                    fontSize = 12.sp
                )
            }
        }
    }
}
