package com.example.trading

import kotlin.math.abs
import kotlin.math.sqrt
import kotlin.random.Random

data class Candle(
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val timestamp: Long
)

enum class SignalType {
    CALL, PUT, NO_SIGNAL
}

data class SignalResult(
    val type: SignalType,
    val confidence: Int, // 40-99
    val reasons: List<String>, // LOC keys
    val marketState: String, // LOC key
    val rsiVal: Double,
    val macdVal: Double,
    val bbandUpper: Double,
    val bbandLower: Double,
    val currentPrice: Double,
    val timeframeText: String
)

object TradingEngine {

    val FOREX_PAIRS = listOf(
        "EUR/USD", "GBP/USD", "USD/JPY", "USD/CHF", "AUD/USD", "NZD/USD", "USD/CAD",
        "EUR/GBP", "EUR/JPY", "GBP/JPY", "AUD/JPY", "CHF/JPY", "CAD/JPY", "NZD/JPY",
        "EUR/AUD", "EUR/CAD", "EUR/CHF", "GBP/CHF", "GBP/CAD", "AUD/CAD", "AUD/CHF",
        "NZD/CAD", "NZD/CHF", "GBP/AUD", "GBP/NZD", "CAD/CHF"
    )

    fun getBasePrice(pair: String): Double {
        return when (pair) {
            "USD/JPY", "EUR/JPY", "GBP/JPY", "AUD/JPY", "CHF/JPY", "CAD/JPY", "NZD/JPY" -> 155.50
            "EUR/USD" -> 1.0852
            "GBP/USD" -> 1.2645
            "USD/CHF" -> 0.9022
            "AUD/USD" -> 0.6614
            "NZD/USD" -> 0.6081
            "USD/CAD" -> 1.3655
            "EUR/GBP" -> 0.8582
            "EUR/AUD" -> 1.6380
            "EUR/CAD" -> 1.4820
            "EUR/CHF" -> 0.9780
            "GBP/CHF" -> 1.1390
            "GBP/CAD" -> 1.7240
            "AUD/CAD" -> 0.9040
            "AUD/CHF" -> 0.5970
            "NZD/CAD" -> 0.8310
            "NZD/CHF" -> 0.5480
            "GBP/AUD" -> 1.9120
            "GBP/NZD" -> 2.0780
            "CAD/CHF" -> 0.6610
            else -> 1.2500
        }
    }

    // Creates historical prices mock series that varies deterministically or randomly based on a Seed
    fun generateHistoricalCandles(pair: String, seed: Long, count: Int = 40): List<Candle> {
        val rand = Random(seed)
        val base = getBasePrice(pair)
        val candleList = mutableListOf<Candle>()
        var lastClose = base - (rand.nextDouble() - 0.5) * (base * 0.02)
        
        for (i in 0 until count) {
            val change = (rand.nextDouble() - 0.49) * (base * 0.003) // subtle upward bias
            val open = lastClose
            val close = open + change
            val high = maxOf(open, close) + rand.nextDouble() * (base * 0.001)
            val low = minOf(open, close) - rand.nextDouble() * (base * 0.001)
            val timestamp = System.currentTimeMillis() - (count - i) * 60000L
            
            candleList.add(Candle(open, high, low, close, timestamp))
            lastClose = close
        }
        return candleList
    }

    // Dynamic price tick update
    fun tickCandles(candles: List<Candle>, seed: Long): List<Candle> {
        if (candles.isEmpty()) return emptyList()
        val temp = candles.toMutableList()
        val rand = Random(System.currentTimeMillis() + seed)
        val last = temp.last()
        val base = last.close
        
        // Simulates rate floating up and down
        val offset = (rand.nextDouble() - 0.5) * (base * 0.0004)
        val updatedCandle = last.copy(
            close = last.close + offset,
            high = maxOf(last.high, last.close + offset),
            low = minOf(last.low, last.close + offset)
        )
        temp[temp.size - 1] = updatedCandle
        return temp
    }

    // --- Mathematical Technical Indicators ---

    fun calculateSMA(candles: List<Candle>, period: Int): Double {
        if (candles.size < period) return candles.lastOrNull()?.close ?: 0.0
        return candles.takeLast(period).map { it.close }.average()
    }

    fun calculateEMA(candles: List<Candle>, period: Int): Double {
        if (candles.size < period) return calculateSMA(candles, period)
        var ema = calculateSMA(candles.take(period), period)
        val multiplier = 2.0 / (period + 1.0)
        for (i in period until candles.size) {
            ema = (candles[i].close - ema) * multiplier + ema
        }
        return ema
    }

    fun calculateRSI(candles: List<Candle>, period: Int = 14): Double {
        if (candles.size <= period) return 50.0
        var gains = 0.0
        var losses = 0.0
        for (i in candles.size - period until candles.size) {
            val diff = candles[i].close - candles[i - 1].open
            if (diff > 0) gains += diff else losses -= diff
        }
        if (losses == 0.0) return 100.0
        val rs = gains / losses
        return 100.0 - (100.0 / (1.0 + rs))
    }

    fun calculateBollingerBands(candles: List<Candle>, period: Int = 20): Pair<Double, Double> {
        val sma = calculateSMA(candles, period)
        if (candles.size < period) return Pair(sma * 1.01, sma * 0.99)
        val lastN = candles.takeLast(period)
        val variance = lastN.map { Math.pow(it.close - sma, 2.0) }.sum() / period
        val sd = sqrt(variance)
        return Pair(sma + 2.0 * sd, sma - 2.0 * sd)
    }

    fun calculateMACD(candles: List<Candle>): Double {
        val ema12 = calculateEMA(candles, 12)
        val ema26 = calculateEMA(candles, 26)
        return ema12 - ema26
    }

    fun calculateStochastic(candles: List<Candle>, period: Int = 14): Double {
        if (candles.size < period) return 50.0
        val lastN = candles.takeLast(period)
        val low = lastN.minOf { it.low }
        val high = lastN.maxOf { it.high }
        if (high == low) return 50.0
        val current = candles.last().close
        return ((current - low) / (high - low)) * 100.0
    }

    fun calculateATR(candles: List<Candle>, period: Int = 14): Double {
        if (candles.size < period) return 0.0
        var totalTR = 0.0
        for (i in candles.size - period until candles.size) {
            val high = candles[i].high
            val low = candles[i].low
            val prevClose = candles[i - 1].close
            val tr = maxOf(high - low, abs(high - prevClose), abs(low - prevClose))
            totalTR += tr
        }
        return totalTR / period
    }

    // --- Technical Strategy Execution ---

    fun analyze(
        pair: String,
        candles: List<Candle>,
        timeframe: String,
        useTimeFilter: Boolean,
        useVolatilityFilter: Boolean,
        useNewsFilter: Boolean,
        onlyStrong: Boolean = false,
        newsImpactCurrency: String = "",
        newsImpactSeverity: String = "" // "NONE", "MEDIUM", "HIGH"
    ): SignalResult {

        val currentPrice = candles.lastOrNull()?.close ?: 1.0
        val reasons = mutableListOf<String>()

        if (candles.size < 30) {
            return SignalResult(
                type = SignalType.NO_SIGNAL,
                confidence = 50,
                reasons = listOf("reason_weak_market"),
                marketState = "state_weak",
                rsiVal = 50.0,
                macdVal = 0.0,
                bbandUpper = currentPrice * 1.005,
                bbandLower = currentPrice * 0.995,
                currentPrice = currentPrice,
                timeframeText = timeframe
            )
        }

        // Calculate actual metrics
        val rsiVal = calculateRSI(candles)
        val stochasticVal = calculateStochastic(candles)
        val macdVal = calculateMACD(candles)
        val (bbUpper, bbLower) = calculateBollingerBands(candles)
        val atr = calculateATR(candles)
        val sma50 = calculateSMA(candles, 30)
        val ema10 = calculateEMA(candles, 10)

        // Session / News / Volatility Filters checks
        var confidencePenalty = 0
        var newsBlocked = false
        var volatilityBlocked = false
        var timeBlocked = false

        // Time / Session logic based on time of day
        val hour = (System.currentTimeMillis() / 3600000 % 24).toInt() // UTC hour
        val isAziSession = hour in 0..8
        val isLondonSession = hour in 7..16
        val isNewYorkSession = hour in 12..21
        val inGoodSession = isLondonSession || isNewYorkSession

        if (useTimeFilter && !inGoodSession) {
            // Slower periods like Asian late session decrease confidence or block
            confidencePenalty += 15
            reasons.add("log_time_block")
        }

        // Volatility checks using ATR relative value
        val relativeATR = atr / currentPrice
        val volatileState = when {
            relativeATR > 0.003 -> {
                if (useVolatilityFilter) {
                    volatilityBlocked = true
                }
                "state_volatile"
            }
            relativeATR < 0.0003 -> {
                confidencePenalty += 12
                "state_weak"
            }
            else -> "state_normal"
        }

        // News impact event check
        val impactedCurrencies = pair.split("/")
        val newsImpactActive = useNewsFilter && newsImpactSeverity == "HIGH" && impactedCurrencies.contains(newsImpactCurrency)
        if (newsImpactActive) {
            newsBlocked = true
            reasons.add("reason_volatile_news")
        }

        // If explicitly blocked by high impact news/volatility, return NO_SIGNAL
        if (newsBlocked) {
            return SignalResult(
                type = SignalType.NO_SIGNAL,
                confidence = 45,
                reasons = listOf("reason_volatile_news"),
                marketState = "state_news",
                rsiVal = rsiVal,
                macdVal = macdVal,
                bbandUpper = bbUpper,
                bbandLower = bbLower,
                currentPrice = currentPrice,
                timeframeText = timeframe
            )
        }

        if (volatilityBlocked) {
            return SignalResult(
                type = SignalType.NO_SIGNAL,
                confidence = 48,
                reasons = listOf("reason_weak_market"),
                marketState = "state_volatile",
                rsiVal = rsiVal,
                macdVal = macdVal,
                bbandUpper = bbUpper,
                bbandLower = bbLower,
                currentPrice = currentPrice,
                timeframeText = timeframe
            )
        }

        // Simple indicators signal logic weight accumulator
        var bullWeight = 0
        var bearWeight = 0

        // 1. RSI Condition
        if (rsiVal < 30) {
            bullWeight += 25
            reasons.add("reason_rsi_os")
        } else if (rsiVal > 70) {
            bearWeight += 25
            reasons.add("reason_rsi_ob")
        }

        // 2. EMA/SMA crossover
        if (ema10 > sma50) {
            bullWeight += 20
            reasons.add("reason_ema_golden")
        } else {
            bearWeight += 20
            reasons.add("reason_ema_death")
        }

        // 3. Bollinger Bands testing
        if (currentPrice < bbLower) {
            bullWeight += 25
            reasons.add("reason_bb_lower")
        } else if (currentPrice > bbUpper) {
            bearWeight += 25
            reasons.add("reason_bb_upper")
        }

        // 4. MACD Trend
        if (macdVal > 0) {
            bullWeight += 15
            reasons.add("reason_macd_up")
        } else {
            bearWeight += 15
            reasons.add("reason_macd_down")
        }

        // 5. Stochastic Oscillator
        if (stochasticVal < 20) {
            bullWeight += 15
            reasons.add("reason_stoch_up")
        } else if (stochasticVal > 80) {
            bearWeight += 15
            reasons.add("reason_stoch_down")
        }

        // Evaluation
        val finalType: SignalType
        var finalConfidence: Int

        if (bullWeight > bearWeight + 20) {
            finalType = SignalType.CALL
            finalConfidence = 75 + ((bullWeight - bearWeight) / 2).coerceIn(0, 24) - confidencePenalty
        } else if (bearWeight > bullWeight + 20) {
            finalType = SignalType.PUT
            finalConfidence = 75 + ((bearWeight - bullWeight) / 2).coerceIn(0, 24) - confidencePenalty
        } else {
            finalType = SignalType.NO_SIGNAL
            finalConfidence = 45 + abs(bullWeight - bearWeight)
            reasons.clear()
            reasons.add("reason_conflict")
        }

        // Respect threshold rule
        val minConfidenceThreshold = if (onlyStrong) 85 else 75
        if (finalConfidence < minConfidenceThreshold) {
            return SignalResult(
                type = SignalType.NO_SIGNAL,
                confidence = finalConfidence.coerceIn(40, 74),
                reasons = listOf("reason_conflict"),
                marketState = volatileState,
                rsiVal = rsiVal,
                macdVal = macdVal,
                bbandUpper = bbUpper,
                bbandLower = bbLower,
                currentPrice = currentPrice,
                timeframeText = timeframe
            )
        }

        return SignalResult(
            type = finalType,
            confidence = finalConfidence.coerceAtMost(99),
            reasons = reasons.distinct().take(3),
            marketState = volatileState,
            rsiVal = rsiVal,
            macdVal = macdVal,
            bbandUpper = bbUpper,
            bbandLower = bbLower,
            currentPrice = currentPrice,
            timeframeText = timeframe
        )
    }
}
