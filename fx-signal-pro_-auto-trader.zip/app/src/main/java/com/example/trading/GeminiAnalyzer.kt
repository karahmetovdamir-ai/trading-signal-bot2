package com.example.trading

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiAnalyzer {

    private const val MODEL = "gemini-3.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun getAIRecommendation(
        pair: String,
        signalType: String,
        confidence: Int,
        timeframe: String,
        rsi: Double,
        macd: Double,
        currentPrice: Double,
        marketState: String,
        lang: String
    ): String = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext if (lang == "RU") {
                "⚠️ API-ключ Gemini не настроен. Отображаются локальные аналитические данные:\n" +
                "• Актив: $pair ($timeframe)\n" +
                "• Сигнал: $signalType (надежность $confidence%)\n" +
                "• RSI: ${String.format("%.2f", rsi)} ($marketState)\n" +
                "• MACD: ${String.format("%.5f", macd)}\n" +
                "• Локальная рекомендация: Инструмент перешел в фазу $marketState. " +
                "Рекомендуется входить только при подтверждении тренда по пробитию Bollinger Bands."
            } else {
                "⚠️ Gemini API Key is not configured. Falling back to local analytical calculations:\n" +
                "• Asset: $pair ($timeframe)\n" +
                "• Signal: $signalType (confidence $confidence%)\n" +
                "• RSI: ${String.format("%.2f", rsi)} ($marketState)\n" +
                "• MACD: ${String.format("%.5f", macd)}\n" +
                "• Pattern analysis: The asset transitioned to $marketState state. " +
                "Recommended entry only on Bollinger Band volume confirmation."
            }
        }

        val prompt = if (lang == "RU") {
            "Действуй как профессиональный Forex-аналитик высокой категории. " +
            "Выполни быстрый краткосрочный анализ для валютной пары $pair ($timeframe).\n" +
            "Текущее состояние:\n" +
            "- Направление сигнала: $signalType\n" +
            "- Уверенность: $confidence%\n" +
            "- Текущая цена: $currentPrice\n" +
            "- Индикатор RSI: ${String.format("%.1f", rsi)}\n" +
            "- Индикатор MACD: ${String.format("%.5f", macd)}\n" +
            "- Состояние рынка: $marketState\n\n" +
            "Напиши 3 профессиональных, кратких и конкретных пункта (почему входить, основные уровни поддержки/сопротивления, совет по риск-менеджменту). Текст должен быть на русском языке, лаконичный и строго практический без лишней воды."
        } else {
            "Act as a professional high-frequency Forex options analyst. " +
            "Perform a swift analytical assessment for $pair ($timeframe).\n" +
            "Current Stats:\n" +
            "- Signal Direction: $signalType\n" +
            "- Confidence: $confidence%\n" +
            "- Spot Price: $currentPrice\n" +
            "- RSI (14): ${String.format("%.1f", rsi)}\n" +
            "- MACD: ${String.format("%.5f", macd)}\n" +
            "- Volatility context: $marketState\n\n" +
            "Generate 3 precise bullet points explaining: 1) why this setup is valid, 2) nearest support/resistance zones, 3) risk control advice. Keep it compact, professional, highly technical under extreme options conditions. Respond in English."
        }

        try {
            val url = "$BASE_URL/v1beta/models/$MODEL:generateContent?key=$apiKey"
            
            val jsonRequest = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", prompt)
                            })
                        })
                    })
                })
            }

            val mediaType = "application/json; charset=utf-8".toMediaType()
            val body = jsonRequest.toString().toRequestBody(mediaType)
            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext "Error: response code ${response.code}"
                }
                val respStr = response.body?.string() ?: return@withContext "Error: empty response"
                val jsonObject = JSONObject(respStr)
                val candidates = jsonObject.getJSONArray("candidates")
                val parts = candidates.getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                parts.getJSONObject(0).getString("text")
            }
        } catch (e: Exception) {
            "Error: ${e.localizedMessage}"
        }
    }
}
